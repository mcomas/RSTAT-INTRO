library(nycflights13)
# data(flights)

# Sense utilitzar la columna month. Filtrar les observacions del
# desembre. Cal utilitzar la columna time_hour
library(tidyverse)
library(lubridate)
select(flights, time_hour)
transmute(flights, 
          time_hour,
          mes = month(time_hour))

filter(flights, month(time_hour) == 12)

# Fem un exemple més senzill
taula = tibble(
  'id' = c(1,2,3,4,5,6),
  'entrada' = c("2006-01-01", "2006-02-02", "2006-02-01",
                "2006-04-23", "2006-01-03", "2006-01-01")
)
taula = mutate(taula, entrada_data = ymd(entrada))
taula
taula = mutate(taula, mes = month(entrada_data))
taula
filter(taula, mes == 2)
filter(taula, month(entrada_data) == 2)
filter(taula, month(ymd(entrada)) == 2)

mutate(taula,
       conte_feb = str_detect(entrada, fixed("-02-")))
mutate(taula,
       conte_feb = str_detect(entrada, "-.3")) 
# Regular expressions
patata = c("patata", " patata", "patata ")
table(patata)
str_trim(patata)
table(str_trim(patata))
str_trim(" patata   ")
patata = c("patata", " patata", "patata ", "PAtata", "Patata")
patata
patata2 = str_trim(patata)
patata2
str_to_lower(patata2)
patata3 = str_to_lower(patata2)
table(patata3)
patata2

neteja_patata <- function(texte){
  texte <- str_trim(texte)
  str_to_lower(texte)
}
neteja_patata(c("patata", " patata", "patata ", "PAtata", "Patata"))
neteja_patata(c("Hola", "hola ", " hola"))

