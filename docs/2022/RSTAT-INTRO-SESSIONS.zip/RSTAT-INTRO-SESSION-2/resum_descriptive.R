library(nycflights13)
library(tidyverse)
# Fem un resum de la variables dep_delay
summarise(flights,
          mean_ = mean(dep_delay, na.rm = TRUE),
          median_ = median(dep_delay, na.rm = TRUE),
          q1_ = quantile(dep_delay, 0.25, na.rm = TRUE),
          q3_ = quantile(dep_delay, 0.75, na.rm = TRUE),
          iqr_ = IQR(dep_delay, na.rm = TRUE),
          min_ = min(dep_delay, na.rm = TRUE),
          max_ = max(dep_delay, na.rm = TRUE) )

# Fem el mateix guardant la descriptiva en una funció

descriptive_flights = function(x){
  summarise(x,
            mean_ = mean(dep_delay, na.rm = TRUE),
            median_ = median(dep_delay, na.rm = TRUE),
            q1_ = quantile(dep_delay, 0.25, na.rm = TRUE),
            q3_ = quantile(dep_delay, 0.75, na.rm = TRUE),
            iqr_ = IQR(dep_delay, na.rm = TRUE),
            min_ = min(dep_delay, na.rm = TRUE),
            max_ = max(dep_delay, na.rm = TRUE) )
}
descriptive_flights(flights)
flights %>%
  descriptive_flights()

# És fàcil reutilitzar la funció per fer una descriptiva mes
# a mes
flights %>%
  group_by(month) %>%
  descriptive_flights()

descriptive_flights(group_by(flights, month))

flights = flights %>%
  mutate(
    arrival = if_else(arr_delay > 0, "delayed", "on-time")
  )

select(flights, arrival, origin)

table(flights[['arrival']], flights[['origin']])
llista = list(
  'a' = 1,
  'b' = 2,
  'c' = 3
)
flights['arrival']
flights[['arrival']]
flights$arrival

count(flights, arrival, origin)
dcount = flights %>%
  count(arrival, origin)


tab = table(flights[['arrival']], flights[['origin']])
dcount = count(flights, arrival, origin)


