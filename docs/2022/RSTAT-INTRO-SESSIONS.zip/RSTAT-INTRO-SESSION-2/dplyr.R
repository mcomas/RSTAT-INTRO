library(nycflights13)
data(package = 'nycflights13')
# Ho podem fer amb qualsevol paquet.
# data(package = 'survival')

data(flights)
str(flights)

library(dplyr)
# filter()
#filtrem els vols de l'u de gener.
flight_1_gener = filter(flights, month == 1, day == 1)
filter(flights, 7 <= month, month <= 9)
filter(flights,  month %in% 7:9)
filter(flights,  month == 7 | month == 8 | month == 9)

filter(flights, dest == "IAH", dest == "HOU")  # Malament
filter(flights, dest == "IAH" & dest == "HOU") # Malament
filter(flights, dest == "IAH" | dest == "HOU")
filter(flights, dest %in% c("IAH","HOU"))

DESTINACIONS = c("IAH","HOU")
filter(flights, dest %in% DESTINACIONS)

c(1,3,2,4,2,3) %in% c(1,2,4)

# la funció distinct()
distinct(flights, month)
distinct(flights, dest)
distinct(flights, origin)
mo = distinct(flights, month, origin)

# arrange()
ord1 = arrange(flights, month, day, dep_delay)
ord2 = arrange(flights, month, day, desc(dep_delay))
ord1

# select()
d4 = select(flights, month, day, flight, year)
d4

select(flights, starts_with('dep_'), contains('arr_'))
select(flights, year, month, day, starts_with('dep_'), contains('arr_'))
select(flights, year:dep_delay)
select(flights, year:dep_delay, -day)

# mutate()
dist_time = select(flights, distance, air_time)
dist_time = mutate(dist_time, 
                   distance_km = distance * 1.60934,
                   air_time_h = air_time / 60,
                   speed_km_h = distance_km / air_time_h)
dist_time

# Només es guarden les columnes creades
trans_tabl = transmute(dist_time, 
                       distance_km = distance * 1.60934,
                       air_time_h = air_time / 60,
                       speed_km_h = distance_km / air_time_h)
