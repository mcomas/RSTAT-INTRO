library(tidyverse)
# Describing a numerical variable
library(nycflights13)
# Volem descriure la variable dep_delay
select(flights, dep_delay)
summarise(flights, 
          dep_del_mean = mean(dep_delay, na.rm = TRUE))
filter(flights, is.na(dep_delay))

taula_resum = summarise(flights, 
                        mida = n(),
                        na = sum(is.na(dep_delay)),
                        na.perc = na / mida * 100,
                        na.perc2 = mean(is.na(dep_delay)) * 100,
                        dep_del_mean = mean(dep_delay, na.rm = TRUE),
                        dep_del_sd = sd(dep_delay, na.rm = TRUE))
taula_resum

# install.packages("writexl")
library(writexl)
write_xlsx(taula_resum, "resum.xlsx")

## Anem a veure la funció group_by()
flights_month = group_by(flights, month) 
taula_resum_2 = summarise(flights_month, 
                          mida = n(),
                          na = sum(is.na(dep_delay)),
                          na.perc = na / mida * 100,
                          na.perc2 = mean(is.na(dep_delay)) * 100,
                          dep_del_mean = mean(dep_delay, na.rm = TRUE),
                          dep_del_sd = sd(dep_delay, na.rm = TRUE))
taula_resum_2

summarise(group_by(flights, month), 
          mida = n(),
          na = sum(is.na(dep_delay)),
          na.perc = na / mida * 100,
          na.perc2 = mean(is.na(dep_delay)) * 100,
          dep_del_mean = mean(dep_delay, na.rm = TRUE),
          dep_del_sd = sd(dep_delay, na.rm = TRUE))
