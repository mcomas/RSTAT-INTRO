library(nycflights13)
library(tidyverse)
# volem seleccionar les columnes  month, day, arr_delay, dep_delay
# i filtrar les observacions del dia 02/02/2013
flights_4var = select(flights, month, day, arr_delay, dep_delay)
filter(flights_4var, month == 2, day == 2)

# El pipe (%>%) agafa l'objecte que té a l'esquerra i 
# el posa com a primer argument de la funció
# que té a la dreta
# x %>% f()
# f(x)
# Per exemple,
flights %>% select(month, day, arr_delay, dep_delay)
select(flights, month, day, arr_delay, dep_delay)

flight_final = flights %>% 
  select(month, day, arr_delay, dep_delay) %>% 
  filter(month == 2, day == 2)

taula_resum_dies = flights %>% 
  select(month, day, arr_delay, dep_delay) %>% 
  filter(month == 2) %>%
  group_by(day) %>%
  summarise(
    m_arr_delay = mean(arr_delay, na.rm = TRUE),
    m_dep_delay = mean(dep_delay, na.rm = TRUE)
  )
taula_resum_dies
library(writexl)
write_xlsx(taula_resum_dies, "resum_dies.xlsx")
