library(tidyverse)
# library(ggplot2)
# library(tibble)
# library(tidyr)
# ...
# library(dplyr)
# library(stringr)
# library(forcats)

# si vulguessim carregar un Excel
library(readxl)


# Avui volem treballar amb dates. Un bon paquet per fer això
# és el lubridate (instal·lat quan hem instal·lat tidyverse)
library(lubridate)

x <- c(20090101, "2009-01-02", "2009 01 03", "2009-1-4",
       "2009-1, 5", "Created on 2009 1 6", "200901 !!! 07")
class(x)
ymd(x)
ddates = ymd(x)
class(ddates)
# Podem sumar dies a les dates
ddates = ddates + days(1)
ddates + months(1)
x2 = "2001-01-31"
ymd(x2) + months(1) # No existeix el 31 de febrer.
ymd(x2) + days(30)
ymd(x2) + years(1)

# També existeixen les funcions year, month, y day
month(ddates)
day(dmy("31/01/2002"))
year(dmy("31/01/2002"))

dnaix = mdy("01/31/1980")
# edat avui
today() - dnaix
# lubridate calcula dies
today() - dnaix
as.numeric(today() - dnaix) / 365.25
interval(dnaix, today()) / years(1)
