library(survival)
library(survminer)
dades = cancer
model_km = survfit( Surv(time = time, event = status == 2)~sex, 
                    data=dades )
model_km
ggsurvplot(model_km, risk.table = TRUE)
