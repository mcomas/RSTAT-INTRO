library(tidyverse)
library(ggstatsplot)
library(readxl)
birthwt = read_excel("birthwt.xlsx")
birthwt = mutate(birthwt, 
                 smoke_fct = factor(smoke, 
                                    levels = c(0,1), 
                                    labels = c('no', 'sí')))

t.test(bwt~smoke_fct, data = birthwt)
ggbetweenstats(birthwt, smoke_fct, bwt,
               plot.type = 'box',
               type = 'parametric') +
  labs(x = "Fumadora", y = "Pes nadons")
ggbetweenstats(birthwt, smoke_fct, bwt,
               plot.type = 'box',
               type = 'parametric', 
               results.subtitle = FALSE, 
               centrality.plotting = FALSE, 
               xlab = "Fumadora",
               ylab = "Pes nadons")
birthwt = mutate(birthwt,
                 low_fct = factor(low, levels = c(0, 1),
                                  labels = c('normopès', 'infrapès')))
X = birthwt$low_fct   # extraiem columna low_fct
Y = birthwt$smoke_fct # extraiem columna 

taula_cont = table(X,Y)

chisq.test(taula_cont)
fisher.test(taula_cont)

ggpiestats(birthwt, smoke_fct, low_fct,
           results.subtitle = FALSE)
  
ggpiestats(birthwt, smoke_fct, low_fct) +
  labs(caption = "", title = "Comparativa",
       subtitle = "entre fumadores i no fumadores")
