# Carregar llibreries que utilitzarem
library(tidyverse)
library(readxl)

# Importació dades Excel
birthwt = read_excel("birthwt.xlsx")

# Creació variable pes en Kg ( x 0,453592) mutate()
birthwt = birthwt %>%
  mutate(
    lwt_kg = lwt * 0.453592
  )
birthwt

# Resum variables de pes
resum_pes_mare_infant = function(taula){
  taula %>%
    summarise(
      n = n(),
      m_mare = mean(lwt_kg, na.rm = TRUE),
      m_inf = mean(bwt, na.rm = TRUE),
      cor_pes = cor(lwt_kg, bwt, use = 'complete.obs')
    )
}
birthwt %>%
  resum_pes_mare_infant()


# Freqüències smoke i pes infant dicotòmic
birthwt %>%
  count(smoke, low) %>%
  group_by(smoke) %>%
  mutate(p = n/sum(n)) %>%
  filter(low == 1)

filter(
  mutate(
    group_by( 
      count(birthwt, smoke, low), smoke), p = n/sum(n)), low == 1)

taula_temp = count(birthwt, smoke, low) 
taula_temp = group_by(taula_temp, smoke)
taula_temp = mutate(taula_temp, p = n/sum(n))
filter(taula_temp, low == 1)

# Mitjana pes infant segons smoking, race i htn
birthwt %>%
  group_by(smoke, race, ht) %>%
  resum_pes_mare_infant()
