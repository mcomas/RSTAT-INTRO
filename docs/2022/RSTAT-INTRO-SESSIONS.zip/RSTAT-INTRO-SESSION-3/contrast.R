X_num = c(10.2, 8.8, 11.2, 9, 9.6, 10.3, 10.2, 13.2, 12.5, 7)
t.test(X_num, mu = 10)
t.test(X_num, mu = 9)
t.test(X_num, mu = 8)

X_bin = c(0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1, 0)
binom.test(sum(X_bin), length(X_bin), 0.4)
binom.test(4, 20, 0.4)


# t-test for mean comparison
library(tidyverse)
taula = tibble(
  X = c(80.8, 78.2, 81, 79.9, 80.7, 79.3, 78.7, 79.6, 79.5, 79.3,  # <- A
        81.8, 81.4, 78.3, 79.4, 82.1, 81.3, 79, 80.5, 81.1, 80.2), # <- B
  G = c(rep('A', 10), rep('B', 10))
)
t.test(X~G, data = taula)  # test-t de Welch
t.test(X~G, data = taula, var.equal = TRUE) # t-test classic

taula2 = tibble(
  A = c(80.8, 78.2, 81, 79.9, 80.7, 79.3, 78.7, 79.6, 79.5, 79.3),
  B = c(81.8, 81.4, 78.3, 79.4, 82.1, 81.3, 79, 80.5, 81.1, 80.2)
)
mutate(taula2,
       diff_BA = B - A)
# funció de tidyr dins del tidyverse
taula3 = pivot_longer(taula2, c('A', 'B')) # obtenim la primera taula
t.test(value~name, data = taula3)  # test-t de Welch

taula4 = pivot_longer(taula2, c('A', 'B'), 
                      names_to = "group", values_to = "X")
taula4
library(readxl)
birth = read_excel("birthwt.xlsx")
birth %>%
  pivot_longer(c('age', 'lwt', 'bwt')) %>%
  group_by(smoke, name) %>%
  summarise(
    mean_ = mean(value),
    sd_ = sd(value)
  )
birth = read_excel("birthwt.xlsx")
taula_neta = select(birth, smoke, age, lwt, bwt)
taula_vertical = pivot_longer(taula_neta, c('age', 'lwt', 'bwt'))
taula_agrupada = group_by(taula_vertical, smoke, name)
summarise(taula_agrupada,
          n = n(),
          mean_ = mean(value),
          sd_ = sd(value))

t.test(value~name, data = taula3)  # test-t de Welch
library(broom)
variable = t.test(value~name, data = taula3)  # test-t de Welch
tidy(variable)
resultat = tidy(t.test(value~name, data = taula3))
save(resultat, file = 'resultat.RData')
library(writexl)
write_xlsx(resultat, "resultat.xlsx")
