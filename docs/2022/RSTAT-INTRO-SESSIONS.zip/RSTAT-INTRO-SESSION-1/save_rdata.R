a = 1:10
b = list(1, 2, 'patata')

save(a, b, file = 'fitxer.RData')

load("fitxer.RData")

# Si volem recuperar un fitxer que
# no estigui al directori de treball, cal
# escriure tota la ruta.
getwd()
load("C:/Users/curs/Documents/RSTAT-INTRO-SESSION-1/fitxer.RData")
# Malament
# load("C:\Users\curs\Documents\RSTAT-INTRO-SESSION-1\fitxer.RData")
# Bé,
# load("C:\\Users\\curs\\Documents\\RSTAT-INTRO-SESSION-1\\fitxer.RData")

