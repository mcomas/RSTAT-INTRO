# Importació de fitxers de texte
library(readr)

taula_dades = read_csv("chickens.csv", show_col_types = FALSE)
a = 4


# Obrir el conjunt jocs-infantils.csv
jocs_infantils <- read_delim("jocs-infantils.csv", 
                             delim = ";", escape_double = FALSE, trim_ws = TRUE)


# Import from Excel
library(readxl)
mtcars = read_excel("datasets.xlsx", sheet = "mtcars")
# mtcars = readxl::read_excel("datasets.xlsx", sheet = "mtcars")

is.list(mtcars)
