
resum = function(x){
  if(!is.numeric(x)){
    stop("Dona'm un valor numèrica")
  }
  cat(sprintf("Mitjana: %.2f\n", mean(x)))
  cat(sprintf("Desv.estand.: %0.2f\n", sd(x)))
  cat(sprintf("Mínim i màxim: %0.2f, %0.2f", min(x), max(x)))
}
mean(c(1,3,2,4,2))
mean("patata")

resum(c(2,5,3,4,6,7,8,4))
resum("patata")


textes = sprintf("Em dic %s, i tinc %d anys. La meva alçada és %0.3f\n", 
                 c("Marc", "Laia"), c(42, 44), c(178.1234, 175.4321))


# Function passing
person = list(
  nom = 'Maria',
  edat = 32
)
print_info = function(person){
  sprintf("%s té %d anys", person$nom, person$edat)
}
print_info(person)
