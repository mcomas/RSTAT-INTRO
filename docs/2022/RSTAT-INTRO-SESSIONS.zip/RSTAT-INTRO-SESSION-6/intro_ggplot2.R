library(tidyverse)
data(mpg, package='ggplot2')
mpg
ggplot()

ggplot(data = mpg) +
  geom_point(mapping = aes(x = displ, y = hwy))

ggplot(data = mpg) +
  geom_point(mapping = aes(x = displ, y = hwy, color = class))

ggplot(data = mpg) +
  geom_point(mapping = aes(x = displ, y = hwy), color = '#29AC32', size = 2)


# Afegim una regressió
ggplot(data = mpg) +
  geom_point(aes(x = displ, y = hwy)) +
  geom_smooth(aes(x = displ, y = hwy), method = 'lm', formula = y~x)

ggplot(data = mpg, aes(x = displ, y = hwy)) +
  geom_smooth(color = 'red', method = 'lm', 
              formula = y~x, se = FALSE) +
  geom_point(alpha = 0.5)

ggplot(data = mpg, aes(x = displ, y = hwy)) +
  geom_smooth(color = 'red', method = 'lm', 
              formula = y~x, se = FALSE) +
  geom_point(aes(color = class), alpha = 0.5) +
  labs(x = "Engine displacement", y = "Consumption")


ggplot(data = mpg, aes(x = displ, y = hwy, color = class)) +  
  geom_smooth(method = 'lm', 
              formula = y~x, se = FALSE) +   
  geom_point(alpha = 1) +
  labs(x = "Engine displacement", y = "Consumption")


# facet
ggplot(mpg, aes(x = displ, y = hwy)) + 
  geom_point(aes(color = class)) + 
  geom_smooth(method = 'lm') +
  facet_wrap(~drv+cyl)

ggplot(mpg, aes(x = displ, y = hwy)) + 
  geom_point(aes(color = class)) + 
  geom_smooth(method = 'lm') +
  facet_grid(year~drv)

ggplot(mpg, aes(x = displ, y = hwy)) + 
  geom_point() + 
  geom_smooth(method = 'lm') +
  facet_grid(year~drv) +
  theme_minimal()

ggplot(mpg, aes(x = displ, y = hwy)) + 
  geom_point() + geom_smooth(method = 'lm') + 
  facet_grid(year~drv) +
  theme_minimal() +
  theme(strip.text = element_text(face = "bold.italic"), 
        strip.background = element_rect(color = 'pink',
                                        size = 2, 
                                        fill = 'blue')) +
  labs(x = "Engine displacement", y = "Highway", title = "Títol")

g1 = ggplot(mpg, aes(x = displ, y = hwy)) + 
  geom_point()
g1
g2 = g1 + geom_smooth(method = 'lm')
g2  
g3 = g2 + facet_grid(year~drv)
g3
gfinal = g3  +
  theme_minimal() +
  theme(strip.text = element_text(face = "bold.italic"), 
        strip.background = element_rect(color = 'pink',
                                        size = 2, 
                                        fill = 'blue'),
        panel.grid = element_line(color = 'black')) +
  labs(x = "Engine displacement", y = "Highway", title = "Títol")
gfinal
ggsave(gfinal, filename = "gfinal.png")

gfinal2 = ggplot(mpg, aes(x = displ, y = hwy)) + 
  geom_point() + 
  geom_smooth(method = 'lm') +
  facet_grid(year~drv) +
  theme_minimal()
gfinal2
ggsave(gfinal2, 
       filename = "final.pdf", 
       width = 4.6, height = 3.2)


ggplot(data=mpg) +
  geom_bar(aes(x = drv))

ggplot(data=mpg) +
  geom_bar(aes(x = drv, y = ..count../sum(..count..)))
