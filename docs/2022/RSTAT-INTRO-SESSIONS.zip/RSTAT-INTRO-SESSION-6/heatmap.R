df = scale(mtcars)

heatmap(df)

library(ggheatmap)
p <- ggheatmap(df,scale = "row", cluster_rows  = TRUE, cluster_cols = TRUE)
p
p$plotlist[[1]] = p$plotlist[[1]] + 
  theme_classic() + 
  labs(fill = "Association") +
  theme(axis.text.y = element_text(colour = 'red'))
p
