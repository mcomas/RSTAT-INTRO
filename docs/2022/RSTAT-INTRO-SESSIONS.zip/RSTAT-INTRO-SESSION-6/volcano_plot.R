library(readxl)
X = read_excel("LINC_data_R.xlsx", sheet = 1)
l1 = read_excel("LINC_data_R.xlsx", sheet = 2, col_names = FALSE)
l2 = read_excel("LINC_data_R.xlsx", sheet = 3, col_names = FALSE)
l3 = read_excel("LINC_data_R.xlsx", sheet = 4, col_names = FALSE)
library(tidyverse)
dplot = X %>%
  mutate(
    l1 = Geneid %in% l1$...1,
    l2 = Geneid %in% l2$...1,
    l3 = Geneid %in% l3$...1,
    log10 = abs(`Neg Log10 pvalue`) < 1.3,
    log2 = abs(logFC.siLINC2.vs.CTRL) < 1,
    colors = factor(log2 | log10, labels = c('Sig.', 'No sig.')))

library(ggplot2)
ggplot() +
  geom_point(data=dplot, 
             aes(x = logFC.siLINC2.vs.CTRL, 
                 y=`Neg Log10 pvalue`, col = colors), 
             alpha=0.4) +
  geom_label(data=filter(dplot, colors == "Sig.", group == 'Pestanya 2'), 
             aes(x = logFC.siLINC2.vs.CTRL, y=`Neg Log10 pvalue`, 
                 label = Geneid,
                 shape = 'RNAseq_down')) +
  geom_text(data=filter(dplot, colors == "Sig.", group == 'Pestanya 3'), 
             aes(x = logFC.siLINC2.vs.CTRL, y=`Neg Log10 pvalue`, 
                 label = Geneid,
                 shape = 'RNAseq_up')) +
  geom_hline(yintercept = 1.3) + geom_vline(xintercept = -1) + 
  geom_vline(xintercept =  1) +
  theme_minimal() + labs(shape = '') + theme(legend.position = 'top') +
  guides(col = 'none') +scale_color_manual(values = c('blue', 'grey'))

# par('din')
ggsave(file = 'volcano_plot.pdf', width = 5.2, height = 3.8)
ggsave(file = 'volcano_plot.png', width = 5.2, height = 3.8)

# install.packages('svglite')
ggsave(file = 'volcano_plot.svg', width = 5.2, height = 3.8)
