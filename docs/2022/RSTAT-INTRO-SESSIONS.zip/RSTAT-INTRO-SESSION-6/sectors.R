library(tidyverse)
library(nycflights13)
dtab = flights %>% count(origin) %>%
  mutate(p = sprintf("%0.1f%%", 100*prop.table(n)),
         cn = rev(cumsum(rev(n))),
         y = cn + diff(c(cn,0))/2 )

ggplot(data=flights) +
  geom_bar(aes(x="",y=(..count..), fill=origin)) +
  geom_text(data=dtab, aes(x="", y=y, label = p)) +
  coord_polar(theta = 'y', start = pi/2, direction = 1) +
  theme_void()



ggplot() +
  geom_density(data=flights, aes(x=dep_delay), col=NA, fill = 'blue', alpha=0.4) +
  scale_x_continuous(limits = c(-30, 60)) +
  scale_y_continuous(limits = c(0, 0.15))

ggplot() +
  geom_histogram(data=flights, aes(x=dep_delay), breaks=seq(-50,1500,5), 
                 fill='blue', alpha=0.4) +
  coord_cartesian(xlim = c(-30,60))


ggplot(data=mpg) +
  geom_boxplot(aes(x = class, y = hwy))

ggplot(data=mpg) +
  geom_density(aes(x = hwy), 
               fill = 'blue', alpha = 0.4, color = NA) +
  facet_wrap(~drv, ncol = 1)
