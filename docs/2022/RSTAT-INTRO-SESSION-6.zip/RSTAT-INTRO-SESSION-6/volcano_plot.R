library(readxl)
X = read_excel("LINC_data_R.xlsx", sheet = 1)
l1 = read_excel("LINC_data_R.xlsx", sheet = 2, col_names = FALSE)
l2 = read_excel("LINC_data_R.xlsx", sheet = 3, col_names = FALSE)
l3 = read_excel("LINC_data_R.xlsx", sheet = 4, col_names = FALSE)
library(tidyverse)
dplot = X %>%
  mutate(
    l1 = Geneid %in% l1$...1,
    l2 = Geneid %in% l2$...1,
    l3 = Geneid %in% l3$...1,
    group = factor(1L + 2L * l1 + 3L * l2,
                   labels = c('group 1', 'group 2', 'group 3')),
    log2 = factor(abs(logFC.siLINC2.vs.CTRL) < 1, labels = c('below','above')))

library(ggplot2)
ggplot() +
  geom_point(data=dplot, aes(x = logFC.siLINC2.vs.CTRL, y=`Neg Log10 pvalue`, col = log2), alpha=0.4) +
  geom_point(data=filter(dplot, group == 'group 2'), aes(x = logFC.siLINC2.vs.CTRL, y=`Neg Log10 pvalue`, shape = 'RNAseq_down')) +
  geom_point(data=filter(dplot, group == 'group 3'), aes(x = logFC.siLINC2.vs.CTRL, y=`Neg Log10 pvalue`, shape = 'RNAseq_up')) +
  theme_minimal() + labs(shape = '') + theme(legend.position = 'top') +
  guides(col = 'none') +scale_color_manual(values = c('blue', 'grey'))

# par('din')
ggsave(file = 'volcano_plot.pdf', width = 5.2, height = 3.8)
ggsave(file = 'volcano_plot.png', width = 5.2, height = 3.8)

# install.packages('svglite')
ggsave(file = 'volcano_plot.svg', width = 5.2, height = 3.8)
