library(tidyverse)
library(readxl)
dades = read_excel("To_box_plot.xlsx", skip = 1)
dplot = pivot_longer(dades, cols = everything())
ggplot(data = dplot, aes(x = name, y = value)) +
  stat_boxplot(geom = 'errorbar', width = 0.5) +
  geom_boxplot(aes(x = name, y = value)) +
  geom_jitter(aes(x = name, y = value), width = 0.1, shape = 21, fill = 'blue') +
  scale_y_continuous(limits = c(0,2)) +
  theme_minimal() +
  labs(x = "", y = "")
  
# par('din')
ggsave(file = 'dot_boxplot.pdf', width = 5.2, height = 3.8)
ggsave(file = 'dot_boxplot.png', width = 5.2, height = 3.8)
# install.packages('svglite')
ggsave(file = 'dot_boxplot.svg', width = 5.2, height = 3.8)